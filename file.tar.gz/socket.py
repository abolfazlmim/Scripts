import socket
print( socket.gethostbyname('www.google.com' ))
